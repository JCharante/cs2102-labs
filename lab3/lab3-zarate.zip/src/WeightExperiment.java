public class WeightExperiment {
    Mouse mouse;
    String date; // in the format of YYYY-MM-DD (see: ISO 8601)
    double weight; // weight of the mouse (unspecified kg or lbs)
}
